python autograder.py -t test_cases/q1/1-small-board
python autograder.py -t test_cases/q1/2-long-bottom
python autograder.py -t test_cases/q1/3-wide-inverted
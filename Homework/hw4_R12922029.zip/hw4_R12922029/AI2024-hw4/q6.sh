python autograder.py -t test_cases/q6/1-ExactUpdate
python autograder.py -t test_cases/q6/2-ExactUpdate
python autograder.py -t test_cases/q6/3-ExactUpdate
python autograder.py -t test_cases/q6/4-ExactUpdate
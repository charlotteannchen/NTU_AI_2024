python autograder.py -t test_cases/q5/1-DiscreteDist-a1
python autograder.py -t test_cases/q5/1-DiscreteDist
python autograder.py -t test_cases/q5/1-ObsProb
python autograder.py -t test_cases/q2/1-product-rule
python autograder.py -t test_cases/q2/2-product-rule-extended
python autograder.py -t test_cases/q2/3-disjoint-right
python autograder.py -t test_cases/q2/4-common-right
python autograder.py -t test_cases/q2/5-grade-join
python autograder.py -t test_cases/q2/6-product-rule-nonsingleton-var
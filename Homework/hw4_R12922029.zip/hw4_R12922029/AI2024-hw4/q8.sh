python autograder.py -t test_cases/q8/1-ExactFull
python autograder.py -t test_cases/q8/2-ExactFull
python autograder.py -t test_cases/q8/3-gameScoreTest
python autograder.py -t test_cases/q4/1-disconnected-eliminate
python autograder.py -t test_cases/q4/2-independent-eliminate
python autograder.py -t test_cases/q4/3-independent-eliminate-extended
python autograder.py -t test_cases/q4/4-common-effect-eliminate
python autograder.py -t test_cases/q4/5-grade-var-elim
python autograder.py -t test_cases/q4/6-large-bayesNet-elim
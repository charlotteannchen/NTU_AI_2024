python autograder.py -t test_cases/q3/1-simple-eliminate
python autograder.py -t test_cases/q3/2-simple-eliminate-extended
python autograder.py -t test_cases/q3/3-eliminate-conditioned
python autograder.py -t test_cases/q3/4-grade-eliminate
python autograder.py -t test_cases/q3/5-simple-eliminate-nonsingleton-var
python autograder.py -t test_cases/q3/6-simple-eliminate-int
python autograder.py -t test_cases/q9/1-ParticleInit
python autograder.py -t test_cases/q9/2-ParticleInit
python autograder.py -t test_cases/q7/1-ExactPredict
python autograder.py -t test_cases/q7/2-ExactPredict
python autograder.py -t test_cases/q7/3-ExactPredict
python autograder.py -t test_cases/q7/4-ExactPredict
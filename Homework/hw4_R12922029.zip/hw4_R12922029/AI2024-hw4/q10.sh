python autograder.py -t test_cases/q10/1-ParticleUpdate
python autograder.py -t test_cases/q10/2-ParticleUpdate
python autograder.py -t test_cases/q10/3-ParticlePredict
python autograder.py -t test_cases/q10/4-ParticlePredict
python autograder.py -t test_cases/q10/5-ParticlePredict
python autograder.py -t test_cases/q10/6-ParticlePredict